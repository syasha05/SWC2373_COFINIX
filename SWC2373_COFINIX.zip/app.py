from flask import Flask, render_template, request, jsonify, url_for, redirect
from flask_cors import CORS
import random
import string
import re

app = Flask(_name_, static_folder='static', template_folder='templates')
CORS(app) 

def generate_room_code():
    """Generate a room code"""
    prefix = "COF-"
    chars = string.ascii_uppercase + string.digits
    suffix = ''.join(random.choices(chars, k=8))
    return prefix + suffix

def validate_room_code(code):
    """Validate that the room code matches the expected format"""
    pattern = r'^COF-[A-Z0-9]{8}$'
    return re.match(pattern, code) is not None

@app.route('/')
def lobby():
    return render_template('index.html')

@app.route('/meeting')
def meeting():
    room_name = request.args.get('room', '').strip().upper()
    is_host = request.args.get('host', "false").lower() == "true"
    
    # If host is creating a new meeting, generate a valid code
    if is_host:
        room_name = generate_room_code()
    # If joining existing meeting, validate the code
    elif not validate_room_code(room_name):
        return redirect(url_for('lobby'))
    
    return render_template('meeting.html', room_name=room_name, is_host=is_host)

if _name_ == 'main':
    app.run(debug=True, host='0.0.0.0', port=5000)